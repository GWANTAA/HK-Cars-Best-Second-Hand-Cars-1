"use client";

import { useState, useMemo } from "react";
import {
  Search,
  Car,
  DollarSign,
  Calendar,
  Filter,
  X,
  Plus,
} from "lucide-react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";

const CAR_TYPES = ["All", "Sedan", "SUV", "Sports"];
const MODELS = ["All", "2023", "2024"];

export default function CarSelectionPage() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedType, setSelectedType] = useState("All");
  const [selectedModel, setSelectedModel] = useState("All");
  const [priceRange, setPriceRange] = useState([0, 150000]);
  const [showFilters, setShowFilters] = useState(true);
  const [sortBy, setSortBy] = useState("name");
  const [showAddForm, setShowAddForm] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false);

  const queryClient = useQueryClient();

  // Fetch cars from API with current filters
  const {
    data: carsData,
    isLoading,
    error,
  } = useQuery({
    queryKey: [
      "cars",
      searchQuery,
      selectedType,
      selectedModel,
      priceRange[0],
      priceRange[1],
      sortBy,
    ],
    queryFn: async () => {
      const params = new URLSearchParams({
        search: searchQuery,
        type: selectedType,
        model: selectedModel,
        minPrice: priceRange[0].toString(),
        maxPrice: priceRange[1].toString(),
        sortBy: sortBy,
      });

      const response = await fetch(`/api/cars?${params}`);
      if (!response.ok) {
        throw new Error(
          `Failed to fetch cars: ${response.status} ${response.statusText}`
        );
      }
      const result = await response.json();
      return result.cars || [];
    },
  });

  const cars = carsData || [];

  // Add car mutation
  const addCarMutation = useMutation({
    mutationFn: async (carData) => {
      const response = await fetch("/api/cars", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(carData),
      });
      if (!response.ok) {
        throw new Error(
          `Failed to add car: ${response.status} ${response.statusText}`
        );
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["cars"] });
      setShowAddForm(false);
    },
    onError: (error) => {
      console.error("Error adding car:", error);
      alert("Failed to add car. Please try again.");
    },
  });

  const resetFilters = () => {
    setSearchQuery("");
    setSelectedType("All");
    setSelectedModel("All");
    setPriceRange([0, 150000]);
    setSortBy("name");
  };

  const handleAddCar = (e) => {
    e.preventDefault();
    const formData = new FormData(e.target);
    const carData = {
      name: formData.get("name"),
      type: formData.get("type"),
      price: parseInt(formData.get("price")),
      model: parseInt(formData.get("model")),
      brand: formData.get("brand"),
      features: formData
        .get("features")
        .split(",")
        .map((f) => f.trim())
        .filter((f) => f),
    };

    if (
      !carData.name ||
      !carData.type ||
      !carData.price ||
      !carData.model ||
      !carData.brand
    ) {
      alert("Please fill in all required fields");
      return;
    }

    addCarMutation.mutate(carData);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      {/* Header */}
      <div className="bg-slate-900/50 backdrop-blur-sm border-b border-slate-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-white flex items-center gap-3">
                <Car className="text-blue-500" size={36} />
                Advanced Car Finder
              </h1>
              <p className="text-slate-400 mt-1">
                Find your perfect vehicle with advanced filtering
              </p>
            </div>
            <div className="flex items-center gap-4">
              {/* Admin Toggle */}
              <label className="flex items-center gap-2 text-slate-300">
                <input
                  type="checkbox"
                  checked={isAdmin}
                  onChange={(e) => setIsAdmin(e.target.checked)}
                  className="rounded"
                />
                Admin Mode
              </label>

              <button
                onClick={() => setShowAddForm(!showAddForm)}
                className="px-4 py-2 bg-green-600 text-white rounded-lg flex items-center gap-2 hover:bg-green-700 transition-colors"
              >
                <Plus size={20} />
                Add Car
              </button>
              <button
                onClick={() => setShowFilters(!showFilters)}
                className="lg:hidden px-4 py-2 bg-blue-600 text-white rounded-lg flex items-center gap-2 hover:bg-blue-700 transition-colors"
              >
                <Filter size={20} />
                {showFilters ? "Hide" : "Show"} Filters
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Add Car Form */}
      {showAddForm && (
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="bg-slate-800/50 backdrop-blur-sm rounded-xl p-6 border border-slate-700 mb-6">
            <h2 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
              <Plus className="text-green-500" size={20} />
              Add New Car
            </h2>
            <form
              onSubmit={handleAddCar}
              className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4"
            >
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-1">
                  Car Name*
                </label>
                <input
                  name="name"
                  type="text"
                  required
                  className="w-full px-3 py-2 bg-slate-900/50 border border-slate-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="e.g., Tesla Model S"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-1">
                  Brand*
                </label>
                <input
                  name="brand"
                  type="text"
                  required
                  className="w-full px-3 py-2 bg-slate-900/50 border border-slate-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="e.g., Tesla"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-1">
                  Type*
                </label>
                <select
                  name="type"
                  required
                  className="w-full px-3 py-2 bg-slate-900/50 border border-slate-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="">Select Type</option>
                  <option value="Sedan">Sedan</option>
                  <option value="SUV">SUV</option>
                  <option value="Sports">Sports</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-1">
                  Price*
                </label>
                <input
                  name="price"
                  type="number"
                  required
                  min="0"
                  className="w-full px-3 py-2 bg-slate-900/50 border border-slate-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="e.g., 50000"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-1">
                  Model Year*
                </label>
                <input
                  name="model"
                  type="number"
                  required
                  min="2020"
                  max="2030"
                  className="w-full px-3 py-2 bg-slate-900/50 border border-slate-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="e.g., 2024"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-1">
                  Features
                </label>
                <input
                  name="features"
                  type="text"
                  className="w-full px-3 py-2 bg-slate-900/50 border border-slate-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="e.g., Electric, Luxury, AWD (comma separated)"
                />
              </div>
              <div className="md:col-span-2 lg:col-span-3 flex gap-3">
                <button
                  type="submit"
                  disabled={addCarMutation.isLoading}
                  className="px-6 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors disabled:opacity-50"
                >
                  {addCarMutation.isLoading ? "Adding..." : "Add Car"}
                </button>
                <button
                  type="button"
                  onClick={() => setShowAddForm(false)}
                  className="px-6 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition-colors"
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Filters Sidebar */}
          <div
            className={`${
              showFilters ? "block" : "hidden"
            } lg:block w-full lg:w-80 flex-shrink-0`}
          >
            <div className="bg-slate-800/50 backdrop-blur-sm rounded-xl p-6 border border-slate-700 sticky top-8">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-bold text-white flex items-center gap-2">
                  <Filter size={20} className="text-blue-500" />
                  Filters
                </h2>
                <button
                  onClick={resetFilters}
                  className="text-sm text-blue-400 hover:text-blue-300 transition-colors"
                >
                  Reset All
                </button>
              </div>

              {/* Search */}
              <div className="mb-6">
                <label className="block text-sm font-medium text-slate-300 mb-2">
                  Search by Name or Brand
                </label>
                <div className="relative">
                  <Search
                    className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"
                    size={20}
                  />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="e.g., Tesla, BMW..."
                    className="w-full pl-10 pr-4 py-3 bg-slate-900/50 border border-slate-600 rounded-lg text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>
              </div>

              {/* Car Type */}
              <div className="mb-6">
                <label className="block text-sm font-medium text-slate-300 mb-2">
                  Car Type
                </label>
                <div className="grid grid-cols-2 gap-2">
                  {CAR_TYPES.map((type) => (
                    <button
                      key={type}
                      onClick={() => setSelectedType(type)}
                      className={`px-4 py-2 rounded-lg font-medium transition-all ${
                        selectedType === type
                          ? "bg-blue-600 text-white shadow-lg shadow-blue-500/30"
                          : "bg-slate-900/50 text-slate-300 hover:bg-slate-700/50 border border-slate-600"
                      }`}
                    >
                      {type}
                    </button>
                  ))}
                </div>
              </div>

              {/* Model Year */}
              <div className="mb-6">
                <label className="block text-sm font-medium text-slate-300 mb-2 flex items-center gap-2">
                  <Calendar size={16} />
                  Model Year
                </label>
                <select
                  value={selectedModel}
                  onChange={(e) => setSelectedModel(e.target.value)}
                  className="w-full px-4 py-3 bg-slate-900/50 border border-slate-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  {MODELS.map((model) => (
                    <option key={model} value={model}>
                      {model}
                    </option>
                  ))}
                </select>
              </div>

              {/* Price Range */}
              <div className="mb-6">
                <label className="block text-sm font-medium text-slate-300 mb-2 flex items-center gap-2">
                  <DollarSign size={16} />
                  Price Range
                </label>
                <div className="space-y-4">
                  <div className="flex items-center gap-4">
                    <input
                      type="number"
                      value={priceRange[0]}
                      onChange={(e) =>
                        setPriceRange([
                          parseInt(e.target.value) || 0,
                          priceRange[1],
                        ])
                      }
                      className="w-full px-3 py-2 bg-slate-900/50 border border-slate-600 rounded-lg text-white text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                      placeholder="Min"
                    />
                    <span className="text-slate-400">-</span>
                    <input
                      type="number"
                      value={priceRange[1]}
                      onChange={(e) =>
                        setPriceRange([
                          priceRange[0],
                          parseInt(e.target.value) || 150000,
                        ])
                      }
                      className="w-full px-3 py-2 bg-slate-900/50 border border-slate-600 rounded-lg text-white text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                      placeholder="Max"
                    />
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="150000"
                    step="5000"
                    value={priceRange[1]}
                    onChange={(e) =>
                      setPriceRange([priceRange[0], parseInt(e.target.value)])
                    }
                    className="w-full accent-blue-500"
                  />
                  <div className="text-center text-sm text-slate-400">
                    ${priceRange[0].toLocaleString()} - $
                    {priceRange[1].toLocaleString()}
                  </div>
                </div>
              </div>

              {/* Sort By */}
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">
                  Sort By
                </label>
                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value)}
                  className="w-full px-4 py-3 bg-slate-900/50 border border-slate-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value="name">Name (A-Z)</option>
                  <option value="price-low">Price (Low to High)</option>
                  <option value="price-high">Price (High to Low)</option>
                  <option value="model">Newest First</option>
                </select>
              </div>
            </div>
          </div>

          {/* Results */}
          <div className="flex-1">
            <div className="mb-6 flex items-center justify-between">
              <h2 className="text-2xl font-bold text-white">
                {isLoading
                  ? "Loading..."
                  : `${cars.length} ${
                      cars.length === 1 ? "Car" : "Cars"
                    } Found`}
              </h2>
            </div>

            {error && (
              <div className="bg-red-600/20 border border-red-500/30 rounded-xl p-6 mb-6">
                <h3 className="text-red-400 font-semibold mb-2">
                  Error loading cars
                </h3>
                <p className="text-red-300">{error.message}</p>
              </div>
            )}

            {!isLoading && !error && cars.length === 0 ? (
              <div className="bg-slate-800/50 backdrop-blur-sm rounded-xl p-12 border border-slate-700 text-center">
                <Car className="mx-auto text-slate-600 mb-4" size={64} />
                <h3 className="text-xl font-semibold text-white mb-2">
                  No cars found
                </h3>
                <p className="text-slate-400 mb-4">
                  Try adjusting your filters to see more results
                </p>
                <button
                  onClick={resetFilters}
                  className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                >
                  Reset Filters
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {cars.map((car) => (
                  <div
                    key={car.id}
                    className="bg-slate-800/50 backdrop-blur-sm rounded-xl p-6 border border-slate-700 hover:border-blue-500 transition-all hover:shadow-xl hover:shadow-blue-500/10 group"
                  >
                    <div className="flex items-start justify-between mb-4">
                      <div>
                        <h3 className="text-xl font-bold text-white group-hover:text-blue-400 transition-colors">
                          {car.name}
                        </h3>
                        <p className="text-slate-400 text-sm">{car.brand}</p>
                      </div>
                      <span className="px-3 py-1 bg-blue-600/20 text-blue-400 rounded-full text-sm font-medium border border-blue-500/30">
                        {car.type}
                      </span>
                    </div>

                    <div className="space-y-3 mb-4">
                      <div className="flex items-center gap-2 text-slate-300">
                        <DollarSign size={18} className="text-green-400" />
                        <span className="font-semibold text-lg">
                          ${car.price.toLocaleString()}
                        </span>
                      </div>
                      <div className="flex items-center gap-2 text-slate-300">
                        <Calendar size={18} className="text-blue-400" />
                        <span>{car.model} Model</span>
                      </div>
                    </div>

                    <div className="flex flex-wrap gap-2 mb-4">
                      {(typeof car.features === "string"
                        ? JSON.parse(car.features)
                        : car.features || []
                      ).map((feature, idx) => (
                        <span
                          key={idx}
                          className="px-2 py-1 bg-slate-700/50 text-slate-300 rounded text-xs border border-slate-600"
                        >
                          {feature}
                        </span>
                      ))}
                    </div>

                    <button
                      onClick={() => (window.location.href = `/cars/${car.id}`)}
                      className="w-full px-4 py-3 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-700 transition-colors shadow-lg shadow-blue-500/20"
                    >
                      View Details & Orders
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
<iframe
  style="width: 100%;"
  height="569"
  src="https://32c2fd9d-3f77-483c-ac7b-6344327b22ab.created.app"
  title="Car Selection Portal"
  frameBorder="0"
></iframe>;