import sql from "@/app/api/utils/sql";

// GET /api/cars/[id] - Get a single car with orders and statistics
export async function GET(request, { params }) {
  try {
    const { id } = params;

    if (!id || isNaN(parseInt(id))) {
      return Response.json(
        { success: false, error: "Invalid car ID" },
        { status: 400 },
      );
    }

    // Get car details
    const carResult = await sql`SELECT * FROM cars WHERE id = ${parseInt(id)}`;

    if (carResult.length === 0) {
      return Response.json(
        { success: false, error: "Car not found" },
        { status: 404 },
      );
    }

    const car = carResult[0];

    // Get orders for this car
    const ordersResult = await sql`
      SELECT * FROM orders 
      WHERE car_id = ${parseInt(id)}
      ORDER BY order_date DESC
    `;

    // Get order statistics
    const statsResult = await sql`
      SELECT 
        COUNT(*) as total_orders,
        COUNT(*) FILTER (WHERE order_status = 'pending') as pending_orders,
        COUNT(*) FILTER (WHERE order_status = 'confirmed') as confirmed_orders,
        COUNT(*) FILTER (WHERE order_status = 'delivered') as delivered_orders,
        COUNT(*) FILTER (WHERE order_status = 'cancelled') as cancelled_orders,
        SUM(total_amount) FILTER (WHERE order_status != 'cancelled') as total_revenue
      FROM orders 
      WHERE car_id = ${parseInt(id)}
    `;

    const stats = statsResult[0];

    return Response.json({
      success: true,
      car: car,
      orders: ordersResult,
      stats: {
        total_orders: parseInt(stats.total_orders) || 0,
        pending_orders: parseInt(stats.pending_orders) || 0,
        confirmed_orders: parseInt(stats.confirmed_orders) || 0,
        delivered_orders: parseInt(stats.delivered_orders) || 0,
        cancelled_orders: parseInt(stats.cancelled_orders) || 0,
        total_revenue: parseInt(stats.total_revenue) || 0,
      },
    });
  } catch (error) {
    console.error("Error fetching car details:", error);
    return Response.json(
      { success: false, error: "Failed to fetch car details" },
      { status: 500 },
    );
  }
}

// PUT /api/cars/[id] - Update a car (admin only)
export async function PUT(request, { params }) {
  try {
    const { id } = params;
    const body = await request.json();

    if (!id || isNaN(parseInt(id))) {
      return Response.json(
        { success: false, error: "Invalid car ID" },
        { status: 400 },
      );
    }

    const { name, type, price, model, brand, features, isAdmin } = body;

    // Simple admin check - in production you'd use proper authentication
    if (!isAdmin) {
      return Response.json(
        { success: false, error: "Admin access required to edit cars" },
        { status: 403 },
      );
    }

    // Build dynamic update query
    const updateFields = [];
    const values = [];
    let paramCount = 0;

    if (name !== undefined) {
      paramCount++;
      updateFields.push(`name = $${paramCount}`);
      values.push(name);
    }

    if (type !== undefined) {
      const validTypes = ["Sedan", "SUV", "Sports"];
      if (!validTypes.includes(type)) {
        return Response.json(
          { success: false, error: "Invalid car type" },
          { status: 400 },
        );
      }
      paramCount++;
      updateFields.push(`type = $${paramCount}`);
      values.push(type);
    }

    if (price !== undefined) {
      if (isNaN(price)) {
        return Response.json(
          { success: false, error: "Price must be a number" },
          { status: 400 },
        );
      }
      paramCount++;
      updateFields.push(`price = $${paramCount}`);
      values.push(parseInt(price));
    }

    if (model !== undefined) {
      if (isNaN(model)) {
        return Response.json(
          { success: false, error: "Model must be a number" },
          { status: 400 },
        );
      }
      paramCount++;
      updateFields.push(`model = $${paramCount}`);
      values.push(parseInt(model));
    }

    if (brand !== undefined) {
      paramCount++;
      updateFields.push(`brand = $${paramCount}`);
      values.push(brand);
    }

    if (features !== undefined) {
      paramCount++;
      updateFields.push(`features = $${paramCount}`);
      values.push(JSON.stringify(features));
    }

    if (updateFields.length === 0) {
      return Response.json(
        { success: false, error: "No fields to update" },
        { status: 400 },
      );
    }

    // Add updated_at field
    paramCount++;
    updateFields.push(`updated_at = $${paramCount}`);
    values.push(new Date().toISOString());

    // Add ID for WHERE clause
    paramCount++;
    values.push(parseInt(id));

    const query = `UPDATE cars SET ${updateFields.join(", ")} WHERE id = $${paramCount} RETURNING *`;
    const result = await sql(query, values);

    if (result.length === 0) {
      return Response.json(
        { success: false, error: "Car not found" },
        { status: 404 },
      );
    }

    return Response.json({ success: true, car: result[0] });
  } catch (error) {
    console.error("Error updating car:", error);
    return Response.json(
      { success: false, error: "Failed to update car" },
      { status: 500 },
    );
  }
}

// DELETE /api/cars/[id] - Delete a car (admin only)
export async function DELETE(request, { params }) {
  try {
    const { id } = params;
    const body = await request.json();
    const { isAdmin } = body;

    if (!id || isNaN(parseInt(id))) {
      return Response.json(
        { success: false, error: "Invalid car ID" },
        { status: 400 },
      );
    }

    // Simple admin check - in production you'd use proper authentication
    if (!isAdmin) {
      return Response.json(
        { success: false, error: "Admin access required to delete cars" },
        { status: 403 },
      );
    }

    // Check if there are any non-cancelled orders for this car
    const activeOrders = await sql`
      SELECT COUNT(*) as count 
      FROM orders 
      WHERE car_id = ${parseInt(id)} AND order_status != 'cancelled'
    `;

    if (parseInt(activeOrders[0].count) > 0) {
      return Response.json(
        {
          success: false,
          error:
            "Cannot delete car with active orders. Cancel all orders first.",
        },
        { status: 400 },
      );
    }

    const result =
      await sql`DELETE FROM cars WHERE id = ${parseInt(id)} RETURNING *`;

    if (result.length === 0) {
      return Response.json(
        { success: false, error: "Car not found" },
        { status: 404 },
      );
    }

    return Response.json({
      success: true,
      message: "Car deleted successfully",
    });
  } catch (error) {
    console.error("Error deleting car:", error);
    return Response.json(
      { success: false, error: "Failed to delete car" },
      { status: 500 },
    );
  }
}
