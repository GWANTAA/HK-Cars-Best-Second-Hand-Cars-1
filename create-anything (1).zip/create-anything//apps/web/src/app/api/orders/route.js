import sql from "@/app/api/utils/sql";

// GET /api/orders - List all orders with optional car_id filter
export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const carId = searchParams.get("car_id");
    const status = searchParams.get("status");

    let query = `
      SELECT 
        o.*,
        c.name as car_name,
        c.brand,
        c.type,
        c.model
      FROM orders o
      JOIN cars c ON o.car_id = c.id
      WHERE 1=1
    `;
    const values = [];
    let paramCount = 0;

    if (carId) {
      paramCount++;
      query += ` AND o.car_id = $${paramCount}`;
      values.push(parseInt(carId));
    }

    if (status) {
      paramCount++;
      query += ` AND o.order_status = $${paramCount}`;
      values.push(status);
    }

    query += " ORDER BY o.order_date DESC";

    const orders = await sql(query, values);

    return Response.json({ success: true, orders });
  } catch (error) {
    console.error("Error fetching orders:", error);
    return Response.json(
      { success: false, error: "Failed to fetch orders" },
      { status: 500 },
    );
  }
}

// POST /api/orders - Create a new order
export async function POST(request) {
  try {
    const body = await request.json();
    const {
      car_id,
      customer_name,
      customer_email,
      customer_phone,
      total_amount,
      delivery_date,
      notes,
    } = body;

    // Validate required fields
    if (!car_id || !customer_name || !customer_email || !total_amount) {
      return Response.json(
        { success: false, error: "Missing required fields" },
        { status: 400 },
      );
    }

    // Validate email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(customer_email)) {
      return Response.json(
        { success: false, error: "Invalid email format" },
        { status: 400 },
      );
    }

    // Check if car exists
    const carExists = await sql`SELECT id FROM cars WHERE id = ${car_id}`;
    if (carExists.length === 0) {
      return Response.json(
        { success: false, error: "Car not found" },
        { status: 404 },
      );
    }

    const result = await sql`
      INSERT INTO orders (
        car_id, 
        customer_name, 
        customer_email, 
        customer_phone, 
        total_amount,
        delivery_date,
        notes
      )
      VALUES (
        ${car_id}, 
        ${customer_name}, 
        ${customer_email}, 
        ${customer_phone || null}, 
        ${parseInt(total_amount)},
        ${delivery_date || null},
        ${notes || null}
      )
      RETURNING *
    `;

    return Response.json({ success: true, order: result[0] });
  } catch (error) {
    console.error("Error creating order:", error);
    return Response.json(
      { success: false, error: "Failed to create order" },
      { status: 500 },
    );
  }
}
