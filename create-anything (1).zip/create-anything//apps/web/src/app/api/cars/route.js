import sql from "@/app/api/utils/sql";

// GET /api/cars - List and search cars with filters
export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const search = searchParams.get("search") || "";
    const type = searchParams.get("type") || "";
    const model = searchParams.get("model") || "";
    const minPrice = searchParams.get("minPrice") || "0";
    const maxPrice = searchParams.get("maxPrice") || "999999";
    const sortBy = searchParams.get("sortBy") || "name";

    // Build dynamic query
    let query = "SELECT * FROM cars WHERE 1=1";
    const values = [];
    let paramCount = 0;

    // Add search filter
    if (search) {
      paramCount++;
      query += ` AND (LOWER(name) LIKE LOWER($${paramCount}) OR LOWER(brand) LIKE LOWER($${paramCount}))`;
      values.push(`%${search}%`);
    }

    // Add type filter
    if (type && type !== "All") {
      paramCount++;
      query += ` AND type = $${paramCount}`;
      values.push(type);
    }

    // Add model filter
    if (model && model !== "All") {
      paramCount++;
      query += ` AND model = $${paramCount}`;
      values.push(parseInt(model));
    }

    // Add price range filter
    paramCount++;
    query += ` AND price >= $${paramCount}`;
    values.push(parseInt(minPrice));

    paramCount++;
    query += ` AND price <= $${paramCount}`;
    values.push(parseInt(maxPrice));

    // Add sorting
    switch (sortBy) {
      case "name":
        query += " ORDER BY name ASC";
        break;
      case "price-low":
        query += " ORDER BY price ASC";
        break;
      case "price-high":
        query += " ORDER BY price DESC";
        break;
      case "model":
        query += " ORDER BY model DESC";
        break;
      default:
        query += " ORDER BY name ASC";
    }

    const cars = await sql(query, values);

    return Response.json({ success: true, cars });
  } catch (error) {
    console.error("Error fetching cars:", error);
    return Response.json(
      { success: false, error: "Failed to fetch cars" },
      { status: 500 },
    );
  }
}

// POST /api/cars - Create a new car
export async function POST(request) {
  try {
    const body = await request.json();
    const { name, type, price, model, brand, features } = body;

    // Validate required fields
    if (!name || !type || !price || !model || !brand) {
      return Response.json(
        { success: false, error: "Missing required fields" },
        { status: 400 },
      );
    }

    // Validate price and model are numbers
    if (isNaN(price) || isNaN(model)) {
      return Response.json(
        { success: false, error: "Price and model must be numbers" },
        { status: 400 },
      );
    }

    // Validate type
    const validTypes = ["Sedan", "SUV", "Sports"];
    if (!validTypes.includes(type)) {
      return Response.json(
        { success: false, error: "Invalid car type" },
        { status: 400 },
      );
    }

    const result = await sql`
      INSERT INTO cars (name, type, price, model, brand, features)
      VALUES (${name}, ${type}, ${parseInt(price)}, ${parseInt(model)}, ${brand}, ${JSON.stringify(features || [])})
      RETURNING *
    `;

    return Response.json({ success: true, car: result[0] });
  } catch (error) {
    console.error("Error creating car:", error);
    return Response.json(
      { success: false, error: "Failed to create car" },
      { status: 500 },
    );
  }
}
