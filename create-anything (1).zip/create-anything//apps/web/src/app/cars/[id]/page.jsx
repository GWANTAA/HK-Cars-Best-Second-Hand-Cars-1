"use client";

import { useState, useMemo } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import {
  Car,
  DollarSign,
  Calendar,
  ArrowLeft,
  Package,
  User,
  Phone,
  Mail,
  Edit,
  Trash2,
  Plus,
  Clock,
  Check,
  X,
  TrendingUp,
} from "lucide-react";

const ORDER_STATUS_COLORS = {
  pending: "bg-yellow-500/20 text-yellow-400 border-yellow-500/30",
  confirmed: "bg-blue-500/20 text-blue-400 border-blue-500/30",
  delivered: "bg-green-500/20 text-green-400 border-green-500/30",
  cancelled: "bg-red-500/20 text-red-400 border-red-500/30",
};

const ORDER_STATUS_ICONS = {
  pending: Clock,
  confirmed: Check,
  delivered: Package,
  cancelled: X,
};

export default function CarDetailPage({ params }) {
  const queryClient = useQueryClient();
  const [showEditForm, setShowEditForm] = useState(false);
  const [showOrderForm, setShowOrderForm] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false);

  // Fetch car details with orders
  const {
    data: carData,
    isLoading,
    error,
  } = useQuery({
    queryKey: ["car", params.id],
    queryFn: async () => {
      const response = await fetch(`/api/cars/${params.id}`);
      if (!response.ok) {
        throw new Error(
          `Failed to fetch car: ${response.status} ${response.statusText}`,
        );
      }
      return response.json();
    },
  });

  // Update car mutation
  const updateCarMutation = useMutation({
    mutationFn: async (carData) => {
      const response = await fetch(`/api/cars/${params.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...carData, isAdmin }),
      });
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || "Failed to update car");
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["car", params.id] });
      queryClient.invalidateQueries({ queryKey: ["cars"] });
      setShowEditForm(false);
    },
    onError: (error) => {
      console.error("Error updating car:", error);
      alert(`Failed to update car: ${error.message}`);
    },
  });

  // Delete car mutation
  const deleteCarMutation = useMutation({
    mutationFn: async () => {
      const response = await fetch(`/api/cars/${params.id}`, {
        method: "DELETE",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ isAdmin }),
      });
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || "Failed to delete car");
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["cars"] });
      window.location.href = "/";
    },
    onError: (error) => {
      console.error("Error deleting car:", error);
      alert(`Failed to delete car: ${error.message}`);
    },
  });

  // Add order mutation
  const addOrderMutation = useMutation({
    mutationFn: async (orderData) => {
      const response = await fetch("/api/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...orderData, car_id: parseInt(params.id) }),
      });
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || "Failed to add order");
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["car", params.id] });
      setShowOrderForm(false);
    },
    onError: (error) => {
      console.error("Error adding order:", error);
      alert(`Failed to add order: ${error.message}`);
    },
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 flex items-center justify-center">
        <div className="text-white text-xl">Loading car details...</div>
      </div>
    );
  }

  if (error || !carData?.success) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 flex items-center justify-center">
        <div className="bg-red-600/20 border border-red-500/30 rounded-xl p-6 text-center max-w-md">
          <h2 className="text-red-400 font-semibold mb-2">Error</h2>
          <p className="text-red-300">{error?.message || "Car not found"}</p>
          <button
            onClick={() => (window.location.href = "/")}
            className="mt-4 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
          >
            Back to Cars
          </button>
        </div>
      </div>
    );
  }

  const { car, orders, stats } = carData;

  const handleEditCar = (e) => {
    e.preventDefault();
    const formData = new FormData(e.target);
    const updates = {
      name: formData.get("name"),
      type: formData.get("type"),
      price: parseInt(formData.get("price")),
      model: parseInt(formData.get("model")),
      brand: formData.get("brand"),
      features: formData
        .get("features")
        .split(",")
        .map((f) => f.trim())
        .filter((f) => f),
    };

    updateCarMutation.mutate(updates);
  };

  const handleAddOrder = (e) => {
    e.preventDefault();
    const formData = new FormData(e.target);
    const orderData = {
      customer_name: formData.get("customer_name"),
      customer_email: formData.get("customer_email"),
      customer_phone: formData.get("customer_phone"),
      total_amount: parseInt(formData.get("total_amount")) || car.price,
      delivery_date: formData.get("delivery_date"),
      notes: formData.get("notes"),
    };

    addOrderMutation.mutate(orderData);
  };

  const handleDeleteCar = () => {
    if (
      window.confirm(
        `Are you sure you want to delete ${car.name}? This action cannot be undone.`,
      )
    ) {
      deleteCarMutation.mutate();
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      {/* Header */}
      <div className="bg-slate-900/50 backdrop-blur-sm border-b border-slate-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <button
                onClick={() => (window.location.href = "/")}
                className="p-2 rounded-lg bg-slate-800 text-slate-300 hover:bg-slate-700 transition-colors"
              >
                <ArrowLeft size={20} />
              </button>
              <div>
                <h1 className="text-3xl font-bold text-white flex items-center gap-3">
                  <Car className="text-blue-500" size={36} />
                  {car.name}
                </h1>
                <p className="text-slate-400 mt-1">
                  {car.brand} • {car.type} • {car.model}
                </p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              {/* Admin Toggle */}
              <label className="flex items-center gap-2 text-slate-300">
                <input
                  type="checkbox"
                  checked={isAdmin}
                  onChange={(e) => setIsAdmin(e.target.checked)}
                  className="rounded"
                />
                Admin Mode
              </label>

              <button
                onClick={() => setShowOrderForm(true)}
                className="px-4 py-2 bg-green-600 text-white rounded-lg flex items-center gap-2 hover:bg-green-700 transition-colors"
              >
                <Plus size={20} />
                New Order
              </button>

              {isAdmin && (
                <>
                  <button
                    onClick={() => setShowEditForm(true)}
                    className="px-4 py-2 bg-blue-600 text-white rounded-lg flex items-center gap-2 hover:bg-blue-700 transition-colors"
                  >
                    <Edit size={20} />
                    Edit Car
                  </button>
                  <button
                    onClick={handleDeleteCar}
                    disabled={deleteCarMutation.isLoading}
                    className="px-4 py-2 bg-red-600 text-white rounded-lg flex items-center gap-2 hover:bg-red-700 transition-colors disabled:opacity-50"
                  >
                    <Trash2 size={20} />
                    {deleteCarMutation.isLoading ? "Deleting..." : "Delete"}
                  </button>
                </>
              )}
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Car Details */}
          <div className="lg:col-span-1">
            <div className="bg-slate-800/50 backdrop-blur-sm rounded-xl p-6 border border-slate-700">
              <h2 className="text-xl font-bold text-white mb-4">Car Details</h2>

              <div className="space-y-4">
                <div className="flex items-center gap-3">
                  <DollarSign size={20} className="text-green-400" />
                  <div>
                    <p className="text-slate-400 text-sm">Price</p>
                    <p className="text-white font-semibold text-lg">
                      ${car.price.toLocaleString()}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <Calendar size={20} className="text-blue-400" />
                  <div>
                    <p className="text-slate-400 text-sm">Model Year</p>
                    <p className="text-white font-semibold">{car.model}</p>
                  </div>
                </div>

                <div>
                  <p className="text-slate-400 text-sm mb-2">Features</p>
                  <div className="flex flex-wrap gap-2">
                    {(typeof car.features === "string"
                      ? JSON.parse(car.features)
                      : car.features || []
                    ).map((feature, idx) => (
                      <span
                        key={idx}
                        className="px-2 py-1 bg-slate-700/50 text-slate-300 rounded text-xs border border-slate-600"
                      >
                        {feature}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            {/* Order Statistics */}
            <div className="bg-slate-800/50 backdrop-blur-sm rounded-xl p-6 border border-slate-700 mt-6">
              <h2 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
                <TrendingUp className="text-green-500" size={20} />
                Order Statistics
              </h2>

              <div className="grid grid-cols-2 gap-4">
                <div className="text-center">
                  <p className="text-2xl font-bold text-white">
                    {stats.total_orders}
                  </p>
                  <p className="text-slate-400 text-sm">Total Orders</p>
                </div>
                <div className="text-center">
                  <p className="text-2xl font-bold text-green-400">
                    ${stats.total_revenue.toLocaleString()}
                  </p>
                  <p className="text-slate-400 text-sm">Revenue</p>
                </div>
                <div className="text-center">
                  <p className="text-2xl font-bold text-blue-400">
                    {stats.confirmed_orders}
                  </p>
                  <p className="text-slate-400 text-sm">Confirmed</p>
                </div>
                <div className="text-center">
                  <p className="text-2xl font-bold text-yellow-400">
                    {stats.pending_orders}
                  </p>
                  <p className="text-slate-400 text-sm">Pending</p>
                </div>
              </div>
            </div>
          </div>

          {/* Orders List */}
          <div className="lg:col-span-2">
            <div className="bg-slate-800/50 backdrop-blur-sm rounded-xl p-6 border border-slate-700">
              <h2 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
                <Package className="text-blue-500" size={20} />
                Orders ({orders.length})
              </h2>

              {orders.length === 0 ? (
                <div className="text-center py-8">
                  <Package className="mx-auto text-slate-600 mb-4" size={64} />
                  <h3 className="text-lg font-semibold text-white mb-2">
                    No orders yet
                  </h3>
                  <p className="text-slate-400">
                    This car hasn't been ordered yet.
                  </p>
                </div>
              ) : (
                <div className="space-y-4 max-h-96 overflow-y-auto">
                  {orders.map((order) => {
                    const StatusIcon = ORDER_STATUS_ICONS[order.order_status];
                    return (
                      <div
                        key={order.id}
                        className="bg-slate-900/50 rounded-lg p-4 border border-slate-600"
                      >
                        <div className="flex items-start justify-between mb-3">
                          <div>
                            <div className="flex items-center gap-2 mb-1">
                              <User size={16} className="text-slate-400" />
                              <p className="font-semibold text-white">
                                {order.customer_name}
                              </p>
                            </div>
                            <div className="flex items-center gap-4 text-sm text-slate-400">
                              <div className="flex items-center gap-1">
                                <Mail size={14} />
                                {order.customer_email}
                              </div>
                              {order.customer_phone && (
                                <div className="flex items-center gap-1">
                                  <Phone size={14} />
                                  {order.customer_phone}
                                </div>
                              )}
                            </div>
                          </div>
                          <div className="text-right">
                            <div
                              className={`inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium border ${ORDER_STATUS_COLORS[order.order_status]}`}
                            >
                              <StatusIcon size={12} />
                              {order.order_status}
                            </div>
                            <p className="text-green-400 font-semibold mt-1">
                              ${order.total_amount.toLocaleString()}
                            </p>
                          </div>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                          <div>
                            <p className="text-slate-400">Order Date</p>
                            <p className="text-white">
                              {new Date(order.order_date).toLocaleDateString()}
                            </p>
                          </div>
                          {order.delivery_date && (
                            <div>
                              <p className="text-slate-400">Delivery Date</p>
                              <p className="text-white">
                                {new Date(
                                  order.delivery_date,
                                ).toLocaleDateString()}
                              </p>
                            </div>
                          )}
                        </div>

                        {order.notes && (
                          <div className="mt-3 pt-3 border-t border-slate-700">
                            <p className="text-slate-400 text-sm mb-1">Notes</p>
                            <p className="text-slate-300 text-sm">
                              {order.notes}
                            </p>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Edit Car Modal */}
      {showEditForm && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-slate-800 rounded-xl p-6 w-full max-w-2xl border border-slate-700">
            <h2 className="text-xl font-bold text-white mb-4">Edit Car</h2>
            <form
              onSubmit={handleEditCar}
              className="grid grid-cols-1 md:grid-cols-2 gap-4"
            >
              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-slate-300 mb-1">
                  Car Name
                </label>
                <input
                  name="name"
                  type="text"
                  defaultValue={car.name}
                  className="w-full px-3 py-2 bg-slate-900/50 border border-slate-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-1">
                  Brand
                </label>
                <input
                  name="brand"
                  type="text"
                  defaultValue={car.brand}
                  className="w-full px-3 py-2 bg-slate-900/50 border border-slate-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-1">
                  Type
                </label>
                <select
                  name="type"
                  defaultValue={car.type}
                  className="w-full px-3 py-2 bg-slate-900/50 border border-slate-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="Sedan">Sedan</option>
                  <option value="SUV">SUV</option>
                  <option value="Sports">Sports</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-1">
                  Price
                </label>
                <input
                  name="price"
                  type="number"
                  defaultValue={car.price}
                  className="w-full px-3 py-2 bg-slate-900/50 border border-slate-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-1">
                  Model Year
                </label>
                <input
                  name="model"
                  type="number"
                  defaultValue={car.model}
                  className="w-full px-3 py-2 bg-slate-900/50 border border-slate-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-slate-300 mb-1">
                  Features (comma separated)
                </label>
                <input
                  name="features"
                  type="text"
                  defaultValue={(typeof car.features === "string"
                    ? JSON.parse(car.features)
                    : car.features || []
                  ).join(", ")}
                  className="w-full px-3 py-2 bg-slate-900/50 border border-slate-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <div className="md:col-span-2 flex gap-3">
                <button
                  type="submit"
                  disabled={updateCarMutation.isLoading}
                  className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50"
                >
                  {updateCarMutation.isLoading ? "Updating..." : "Update Car"}
                </button>
                <button
                  type="button"
                  onClick={() => setShowEditForm(false)}
                  className="px-6 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition-colors"
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* New Order Modal */}
      {showOrderForm && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-slate-800 rounded-xl p-6 w-full max-w-2xl border border-slate-700">
            <h2 className="text-xl font-bold text-white mb-4">
              New Order for {car.name}
            </h2>
            <form
              onSubmit={handleAddOrder}
              className="grid grid-cols-1 md:grid-cols-2 gap-4"
            >
              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-slate-300 mb-1">
                  Customer Name*
                </label>
                <input
                  name="customer_name"
                  type="text"
                  required
                  className="w-full px-3 py-2 bg-slate-900/50 border border-slate-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="John Doe"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-1">
                  Email*
                </label>
                <input
                  name="customer_email"
                  type="email"
                  required
                  className="w-full px-3 py-2 bg-slate-900/50 border border-slate-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="john@example.com"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-1">
                  Phone
                </label>
                <input
                  name="customer_phone"
                  type="tel"
                  className="w-full px-3 py-2 bg-slate-900/50 border border-slate-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="555-0123"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-1">
                  Total Amount*
                </label>
                <input
                  name="total_amount"
                  type="number"
                  required
                  defaultValue={car.price}
                  className="w-full px-3 py-2 bg-slate-900/50 border border-slate-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-1">
                  Expected Delivery Date
                </label>
                <input
                  name="delivery_date"
                  type="date"
                  className="w-full px-3 py-2 bg-slate-900/50 border border-slate-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-slate-300 mb-1">
                  Notes
                </label>
                <textarea
                  name="notes"
                  rows={3}
                  className="w-full px-3 py-2 bg-slate-900/50 border border-slate-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="Special requests, modifications, etc."
                />
              </div>
              <div className="md:col-span-2 flex gap-3">
                <button
                  type="submit"
                  disabled={addOrderMutation.isLoading}
                  className="px-6 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors disabled:opacity-50"
                >
                  {addOrderMutation.isLoading
                    ? "Creating Order..."
                    : "Create Order"}
                </button>
                <button
                  type="button"
                  onClick={() => setShowOrderForm(false)}
                  className="px-6 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition-colors"
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
